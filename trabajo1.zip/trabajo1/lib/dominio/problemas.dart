abstract class Problema{

}

class UsuarioNoRegistrado extends Problema{

}
